#%%
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.svm import SVR 
from sklearn.metrics import mean_squared_error, mean_absolute_error,mean_absolute_percentage_error,r2_score
from math import sqrt
import statsmodels.api as sm
import matplotlib.pyplot as plt


#%%
data = pd.read_csv("Data-246.csv",header=1) 

Y = data.loc[:,'y']
YY=data.loc[:,'yy']
X = data.drop(['y','yy'],axis=1)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=5)

regr=RandomForestRegressor(max_depth=6, min_samples_split=5, min_samples_leaf=3, random_state=2)
# regr = MLPRegressor(hidden_layer_sizes=(5,8),learning_rate_init=0.01,max_iter=5000,random_state=9, verbose=False)
# regr = SVR(C=50,tol=0.01,epsilon=0.5, coef0=0,kernel='rbf')

model = regr.fit(x_train.values, np.log(y_train.values))
y_pred = model.predict(x_test)
y_pred_train = model.predict(x_train)

print("rmse \t:", sqrt(mean_squared_error(np.log(y_test.values), y_pred)))
print("mae \t:", mean_absolute_error(np.log(y_test.values), y_pred))
print("mape \t:", mean_absolute_percentage_error(np.log(y_test.values), y_pred))
print("r2 \t:", r2_score(np.log(y_test.values), y_pred))

print("rmse_train \t:", sqrt(mean_squared_error(np.log(y_train.values), y_pred_train)))
print("mae_train \t:", mean_absolute_error(np.log(y_train.values),y_pred_train))
print("mape \t:", mean_absolute_percentage_error(np.log(y_train.values), y_pred_train))
print("r2_train \t:", r2_score(np.log(y_train.values), y_pred_train))

# train=np.concatenate((np.log(y_train.values).reshape(-1,1),y_pred_train.reshape(-1,1)),axis=1)
# test=np.concatenate((np.log(y_test.values).reshape(-1,1),y_pred.reshape(-1,1)),axis=1)
# pd.DataFrame(train,columns=['train','pred_train']).to_csv("Train.csv")
# pd.DataFrame(test,columns=['test','pred_test']).to_csv("Test.csv")
#%%
pre=model.predict(X).reshape(-1,1)
xx = sm.add_constant(pre)
fit=sm.OLS(np.log(Y.values),xx).fit()
print(fit.summary())
fig,fig = plt.subplots(figsize=(15,15))
fig.plot(y_pred_train.reshape(-1,1),np.log(y_train.values),'ro',label="Samples")
fig.plot(y_pred.reshape(-1,1),np.log(y_test.values),'bo',label="Testing data")
fig.plot(pre,fit.fittedvalues,"k",label="Best fitted line")
fig.legend(loc="best",fontsize=20)
plt.tick_params(labelsize=20)
plt.xlabel('Simulated Result',fontsize=25)
plt.ylabel('Real Result',fontsize=25)
#%%
XX = sm.add_constant(YY)
fit=sm.OLS(np.log(Y.values),np.log(XX)).fit()
print(fit.summary())


