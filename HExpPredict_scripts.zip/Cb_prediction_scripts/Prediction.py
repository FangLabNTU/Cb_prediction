#%%
import pandas as pd
import numpy as np
from Regression import model

#%%
var=pd.read_csv("Prediction_Set.csv",header=1)
pre=model.predict(var)
# pd.DataFrame(pre).to_csv("Results.csv")
