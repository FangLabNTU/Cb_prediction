Regression trains the model;
Prediction predicts new materials;
MC runs the Monte-Carlo simulation.