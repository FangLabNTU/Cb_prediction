#!/usr/bin/env python
# coding: utf-8

# In[3]:


import math
import numpy as np
import pandas as pd
from Regression import model

# In[4]:
data = pd.read_csv("MC_Data2.csv", header=1).values

n=1000
#%%
def mc(x): 
    m=x.shape[0]
    d05=np.zeros((m,1))
    d50=np.zeros((m,1))
    d95=np.zeros((m,1))
    for i in range (0,m):
        x1_0=x[i,0] 
        x2_0=x[i,1] 
        x3_0=x[i,2] 
        x4_0=x[i,3] 
        x5_0=x[i,4] 
        x6_0=x[i,5] 
        x7_0=x[i,6] 
        
        
        mu_x1=x1_0
        sigma_x1=x[i,7]
        mu_x3=x3_0
        sigma_x3=x[i,8]
        x1=np.random.normal(mu_x1, sigma_x1, n).reshape(-1,1)
        # x1=x1_0*np.ones((n,1))
        x2=x2_0*np.ones((n,1))
        # x3=np.random.normal(mu_x3, sigma_x3, n).reshape(-1,1)
        x3=x3_0*np.ones((n,1))
        x4=x4_0*np.ones((n,1))
        x5=x5_0*np.ones((n,1))
        x6=x6_0*np.ones((n,1))
        x7=x7_0*np.ones((n,1))
        x2=x2_0*np.ones((n,1))
        
        var=pd.DataFrame(np.hstack((x1,x2,x3,x4,x5,x6,x7))) #Define input parameters with uncertainty
    
        
        pre=np.sort(model.predict(var))
        
        d05[i]=pre[49]
        d50[i]=(pre[499]+pre[500])/2
        d95[i]=pre[949]
    return d05,d50,d95

#%%
d05,d50,d95=mc(data)
mc_result=np.concatenate((d05,d50,d95),axis=1)
pd.DataFrame(mc_result,columns=['d05','d50','d95']).to_csv("MC_Results2_x1.csv")
#%%